<?php
  $page_title = 'Bienvenidos a Global Backups';
  require_once('includes/load.php');
  if (!$session->isUserLoggedIn(true)) { redirect('index.php', false);}
?>
<?php include_once('layouts/header.php'); ?>
<div class="col-md-12">
  <div class="panel">
    <div class="jumbotron text-center">
      <!-- Imagen agregada -->
      <img src="uploads/GLOBALBACKUPS.png" alt="Logo de Global Backups" style="max-width: 350px; margin-bottom: 20px;">
      <h1>Global Backups Universidad</h1>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?> 
