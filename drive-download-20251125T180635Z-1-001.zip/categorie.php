  <?php
  $page_title = 'Lista de DEPARTAMENTOs';
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
  page_require_level(1);
  
  $all_DEPARTAMENTO = find_all('DEPARTAMENTO')
?>
<?php
 if(isset($_POST['add_cat'])){
   $req_field = array('categorie-name');
   validate_fields($req_field);
   $cat_name = remove_junk($db->escape($_POST['categorie-name']));
   if(empty($errors)){
      $sql  = "INSERT INTO categories (nombre)";
      $sql .= " VALUES ('{$cat_name}')";
      if($db->query($sql)){
        $session->msg("s", "Categoría agregada exitosamente.");
        redirect('categorie.php',false);
      } else {
        $session->msg("d", "Lo siento, registro falló");
        redirect('categorie.php',false);
      }
   } else {
     $session->msg("d", $errors);
     redirect('categorie.php',false);
   }
 }
?>
<?php include_once('layouts/header.php'); ?>

<div class="row">
  <div class="col-md-12">
    <?php echo display_msg($msg); ?>
  </div>
</div>

<div class="row">
  <!-- PANEL AGREGAR DEPARTAMENTO (más pequeño) -->
  <div class="col-md-4">
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>Agregar DEPARTAMENTO</span>
        </strong>
      </div>
      <div class="panel-body">
        <form method="post" action="categorie.php">
          <div class="form-group">

            <input type="text" class="form-control" name="categorie-name" placeholder="Nombre del departamento" required>
            <input type="text" class="form-control" name="categorie-name" placeholder="Feche de Creacion Dpto" required>
            <input type="text" class="form-control" name="categorie-name" placeholder="Telefono Dpto" required>
            <input type="text" class="form-control" name="categorie-name" placeholder="Email Dpto" required>
            <input type="text" class="form-control" name="categorie-name" placeholder="Coordinador Dpto" required>

          </div>
          <button type="submit" name="add_cat" class="btn btn-primary">Agregar DEPARTAMENTO</button>
        </form>
      </div>
    </div>
  </div>

  <!-- PANEL LISTA DE DEPARTAMENTO (recorrido hacia la izquierda) -->
  <div class="col-md-8" style="margin-left:-30px;">
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>Lista de DEPARTAMENTO</span>
        </strong>
      </div>

      <div class="panel-body">
        <table class="table table-bordered table-striped table-hover">
          <thead>
            <tr>
              <th class="text-center" style="width: 50px;">#</th>
              <th class="text-center">Nombre</th>
              <th class="text-center">FechaCreación</th>
              <th class="text-center">Teléfono</th>
              <th class="text-center">Email</th>
              <th class="text-center">Coordinador</th>
              <th class="text-center">Acciones</th>
            </tr>
          </thead>

          <tbody>
            <?php foreach ($all_DEPARTAMENTO as $dep): ?>
              <tr>
                <td class="text-center"><?php echo count_id(); ?></td>
                <td><?php echo remove_junk(ucfirst($dep['Nombre_Dpto'])); ?></td>
                <td><?php echo remove_junk(ucfirst($dep['FecheCreacion_Dpto'])); ?></td>
                <td><?php echo remove_junk(ucfirst($dep['Telefono_Dpto'])); ?></td>
                <td><?php echo remove_junk(ucfirst($dep['Email_Dpto'])); ?></td>
                <td><?php echo remove_junk(ucfirst($dep['Coordinador_Dpto'])); ?></td>

                <td class="text-center">
                  <div class="btn-group">
                    <a href="edit_categorie.php?id=<?php echo (int)$dep['PK_Cod_Dpto']; ?>" class="btn btn-xs btn-warning" title="Editar">
                      <span class="glyphicon glyphicon-edit"></span>
                    </a>
                    <a href="delete_categorie.php?id=<?php echo (int)$dep['PK_Cod_Dpto']; ?>" class="btn btn-xs btn-danger" title="Eliminar">
                      <span class="glyphicon glyphicon-trash"></span>
                    </a>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>

        </table>
      </div>
    </div>
  </div>
</div>

  <?php include_once('layouts/footer.php'); ?>
