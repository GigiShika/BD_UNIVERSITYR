<ul>
  
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-user"></i>
      <span>Usuarios</span>
    </a>
    <ul class="nav submenu">
      <li><a href="group.php">Administrar grupos</a> </li>
      <li><a href="users.php">Administrar usuarios</a> </li>
   </ul>
  </li>
  <li>
    <a href="categorie.php" >
      <i class="glyphicon glyphicon-indent-left"></i>
      <span>DEPARTAMENTOS</span>
    </a>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-th-large"></i>
      <span>Todos los DEPARTAMENTOS</span>
    </a>
    <ul class="nav submenu">
       <li><a href="product.php">Administrar DEPARTAMENTO</a> </li>
       <li><a href="add_product.php">Agregar DEPARTAMENTO</a> </li>
   </ul>
  </li>
  <li>
    <a href="product.php" >
      <i class="glyphicon glyphicon-indent-left"></i>
      <span>AREAs DE CONOCIMIENTO</span>
    </a>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-th-large"></i>
      <span>Todas las AREAS DE CONOCIMIENTO</span>
    </a>
    <ul class="nav submenu">
       <li><a href="product.php">Administrar AREA_CONOCIMIENTO</a> </li>
       <li><a href="add_product.php">Agregar AREA_CONOCIMIENTO</a> </li>
   </ul>
  </li>
   <li>
      <a href="categorie.php" >
      <i class="glyphicon glyphicon-indent-left"></i>
      <span>PROFESORES</span>
    </a>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-th-large"></i>
      <span>Todos los PROFESORES</span>
    </a>
    <ul class="nav submenu">
       <li><a href="product.php">Administrar PROFESOR</a> </li>
       <li><a href="add_product.php">Agregar PROFESOR</a> </li>
   </ul>
  </li>
   <li>
      <a href="categorie.php" >
      <i class="glyphicon glyphicon-indent-left"></i>
      <span>ASIGNATURA</span>
    </a>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-th-large"></i>
      <span>Todas las ASIGNATURAS</span>
    </a>
    <ul class="nav submenu">
       <li><a href="product.php">Administrar ASIGNATURA</a> </li>
       <li><a href="add_product.php">Agregar ASIGNATURA</a> </li>
   </ul>
  </li>
   <li>
      <a href="categorie.php" >
      <i class="glyphicon glyphicon-indent-left"></i>
      <span>TITULACION</span>
    </a>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-th-large"></i>
      <span>Todos las TITULACIONES</span>
    </a>
    <ul class="nav submenu">
       <li><a href="product.php">Administrar TITULACION</a> </li>
       <li><a href="add_product.php">Agregar TITULACION</a> </li>
   </ul>
  </li>
  
</ul>
