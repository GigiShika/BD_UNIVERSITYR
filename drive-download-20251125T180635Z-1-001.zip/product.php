<?php
  $page_title = 'Lista de area de conocimientos';
  require_once('includes/load.php');
  page_require_level(3);

  // Obtener productos con imagen usando el alias 'image'
  $areaC = join_area_conocimiento_table();
?>

<?php include_once('layouts/header.php'); ?>

<div class="row">
  <div class="col-md-12">
    <?php echo display_msg($msg); ?>
  </div>
  <div class="col-md-12">
    <div class="panel panel-default">
      <div class="panel-heading clearfix">
        <div class="pull-right">
          <a href="add_product.php" class="btn btn-primary">Agregar area de conocimiento</a>
        </div>
      </div>
      <div class="panel-body">
        <table class="table table-bordered">
          <thead>
            <tr>
              <th class="text-center" style="width: 50px;">#</th>
              <th>Nombre Area</th>
              <th class="text-center" style="width: 10%;">Descripcion Area</th>
              <th class="text-center" style="width: 10%;">Coordinador Area</th>
              <th class="text-center" style="width: 10%;">FechaCreacion Area</th>
              <th class="text-center" style="width: 10%;">NumProfesores Area</th>
              <th class="text-center" style="width: 10%;">DEPARTAMENTO</th>
              <th class="text-center">Acciones</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($areaC as $AreaC): ?>
            <tr>
              <td class="text-center"><?php echo count_id(); ?></td>

              <td><?php echo remove_junk($AreaC['Nombre_Area']); ?></td>
              <td class="text-center"><?php echo remove_junk($AreaC['Descripcion_Area']); ?></td>
              <td class="text-center"><?php echo remove_junk($AreaC['Coordinador_Area']); ?></td>
              <td class="text-center"><?php echo remove_junk($AreaC['FechaCreacion_Area']); ?></td>
              <td class="text-center"><?php echo remove_junk($AreaC['NumProfesores_Area']); ?></td>
              <td class="text-center"><?php echo remove_junk($AreaC['Nombre_Dpto']); ?></td>

              
              <td class="text-center">
                <div class="btn-group">
                  <a href="edit_product.php?id=<?php echo (int)$AreaC['PK_Cod_Area']; ?>" class="btn btn-info btn-xs" title="Editar" data-toggle="tooltip">
                    <span class="glyphicon glyphicon-edit"></span>
                  </a>
                  <a href="delete_product.php?id=<?php echo (int)$AreaC['PK_Cod_Area']; ?>" class="btn btn-danger btn-xs" title="Eliminar" data-toggle="tooltip" onclick="return confirm('¿Seguro que deseas eliminar este producto?');">
                    <span class="glyphicon glyphicon-trash"></span>
                  </a>
                </div>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<?php include_once('layouts/footer.php'); ?>
