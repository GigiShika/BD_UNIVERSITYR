<?php
// -----------------------------------------------------------------------
// DEFINE SEPARATORS
// -----------------------------------------------------------------------
define("URL_SEPARATOR", '/'); // Usado para URLs
define("DS", DIRECTORY_SEPARATOR); // Usado para rutas de sistema

// -----------------------------------------------------------------------
// DEFINE ROOT PATHS
// -----------------------------------------------------------------------
defined('SITE_ROOT') ? null : define('SITE_ROOT', realpath(dirname(__FILE__) . DS . '..'));
define("LIB_PATH_INC", SITE_ROOT . DS . "includes" . DS);

// -----------------------------------------------------------------------
// CARGA LOS ARCHIVOS NECESARIOS
// -----------------------------------------------------------------------
require_once(LIB_PATH_INC . 'config.php');      // Configuración general (DB, constantes, etc.)
require_once(LIB_PATH_INC . 'functions.php');   // Funciones auxiliares
require_once(LIB_PATH_INC . 'session.php');     // Gestión de sesiones
require_once(LIB_PATH_INC . 'upload.php');      // Gestión de archivos e imágenes
require_once(LIB_PATH_INC . 'database.php');    // Conexión a la base de datos
require_once(LIB_PATH_INC . 'sql.php');         // Funciones de consulta SQL personalizadas

// -----------------------------------------------------------------------
// CARGA LA CONEXIÓN A LA BD
// -----------------------------------------------------------------------
if (!isset($db)) {
  global $db;
  $db = new MySqli_DB(); // Clase definida en database.php
}
?>
