<?php
  const base_url = "http://localhost/rel_universidad/";
  define( 'DB_HOST', 'localhost' );          
  define( 'DB_USER', 'root' );             
  define( 'DB_PASS', '' );             
  define( 'DB_NAME', 'rel_universidad' );        
?>
