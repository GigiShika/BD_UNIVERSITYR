-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 19-11-2025 a las 03:46:16
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `rel_universidad`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `area_conocimiento`
--

CREATE TABLE `area_conocimiento` (
  `PK_Cod_Area` int(11) NOT NULL,
  `Nombre_Area` varchar(30) NOT NULL,
  `Descripcion_Area` tinytext NOT NULL,
  `Coordinador_Area` varchar(30) NOT NULL,
  `FechaCreacion_Area` varchar(10) NOT NULL,
  `NumProfesores_Area` int(2) NOT NULL,
  `FK_Cod_Dpto` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asignatura`
--

CREATE TABLE `asignatura` (
  `PK_Cod_Asign` int(11) NOT NULL,
  `Nombre_Asign` varchar(30) NOT NULL,
  `HorasTeoria_Asign` int(3) NOT NULL,
  `HorasPractica_Asign` int(3) NOT NULL,
  `Creditos_Asign` int(4) NOT NULL,
  `Semestre_Asign` varchar(30) NOT NULL,
  `Tipo_Asign` varchar(30) NOT NULL,
  `FK_Cod_Area` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cursador`
--

CREATE TABLE `cursador` (
  `id_cursador` int(11) NOT NULL,
  `FK_Cod_Prof` int(11) NOT NULL,
  `FK_Cod_Asign` int(11) NOT NULL,
  `FK_Cod__Titulac` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `departamento`
--

CREATE TABLE `departamento` (
  `PK_Cod_Dpto` int(11) NOT NULL,
  `Nombre_Dpto` varchar(30) NOT NULL,
  `FecheCreacion_Dpto` varchar(10) NOT NULL,
  `Telefono_Dpto` int(10) NOT NULL,
  `Email_Dpto` text NOT NULL,
  `Coordinador_Dpto` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `profesor`
--

CREATE TABLE `profesor` (
  `PK_Cod_Prof` int(11) NOT NULL,
  `Nombre_Prof` varchar(30) NOT NULL,
  `Apellidos_Prof` varchar(30) NOT NULL,
  `Especialidad_Prof` tinytext NOT NULL,
  `FechaContratacion_Prof` int(10) NOT NULL,
  `Email_Prof` tinytext NOT NULL,
  `Telefono_Prof` int(10) NOT NULL,
  `FK_Cod_Area` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `titulacion`
--

CREATE TABLE `titulacion` (
  `PK_Cod_Titulac` int(11) NOT NULL,
  `Nombre_Titulac` int(11) NOT NULL,
  `Duracion_Titulac` int(11) NOT NULL,
  `CreditosTotales_Titulac` int(11) NOT NULL,
  `Tipo_Titulac` int(11) NOT NULL,
  `FechaCreacion_Titulac` int(11) NOT NULL,
  `Coordinador_Titulac` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `area_conocimiento`
--
ALTER TABLE `area_conocimiento`
  ADD PRIMARY KEY (`PK_Cod_Area`);

--
-- Indices de la tabla `asignatura`
--
ALTER TABLE `asignatura`
  ADD PRIMARY KEY (`PK_Cod_Asign`);

--
-- Indices de la tabla `cursador`
--
ALTER TABLE `cursador`
  ADD PRIMARY KEY (`id_cursador`);

--
-- Indices de la tabla `departamento`
--
ALTER TABLE `departamento`
  ADD PRIMARY KEY (`PK_Cod_Dpto`);

--
-- Indices de la tabla `profesor`
--
ALTER TABLE `profesor`
  ADD PRIMARY KEY (`PK_Cod_Prof`);

--
-- Indices de la tabla `titulacion`
--
ALTER TABLE `titulacion`
  ADD PRIMARY KEY (`PK_Cod_Titulac`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `area_conocimiento`
--
ALTER TABLE `area_conocimiento`
  MODIFY `PK_Cod_Area` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `asignatura`
--
ALTER TABLE `asignatura`
  MODIFY `PK_Cod_Asign` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `cursador`
--
ALTER TABLE `cursador`
  MODIFY `id_cursador` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `departamento`
--
ALTER TABLE `departamento`
  MODIFY `PK_Cod_Dpto` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `profesor`
--
ALTER TABLE `profesor`
  MODIFY `PK_Cod_Prof` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `titulacion`
--
ALTER TABLE `titulacion`
  MODIFY `PK_Cod_Titulac` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
