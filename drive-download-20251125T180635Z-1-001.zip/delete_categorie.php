<?php
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
  page_require_level(1);
?>
<?php
  $DEPARTAMENTO = find_by_id('DEPARTAMENTO',id: (int)$_GET['PK_Cod_Dpto']);
  if(!$DEPARTAMENTO){
    $session->msg("d","ID de la DEPARTAMENTO falta.");
    redirect('categorie.php');
  }
?>
<?php
  $delete_id = delete_by_id('DEPARTAMENTO',(int)$DEPARTAMENTO['PK_Cod_Dpto']);
  if($delete_id){
      $session->msg("s","DEPARTAMENTO eliminada");
      redirect('categorie.php');
  } else {
      $session->msg("d","Eliminación falló");
      redirect('categorie.php');
  }
?>
